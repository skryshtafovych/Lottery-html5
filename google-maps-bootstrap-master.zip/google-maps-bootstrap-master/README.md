google-maps-bootstrap
=====================

Basic app that plots some points(in this case SDA churches) on a map and builds a route on request.

Very nice!!! 

Uses: 
- Google Maps V3 
- Twitter Bootstrap
- HTML5 Navigator

Clone and open home.html in your browser, should work immediately.

Also you could go to www.freshlybaked.co.za/find-a-church/home.html

Have fun...